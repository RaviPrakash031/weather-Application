const apikey = "aY75OrA8yEsAlVv2Ozffqpf8yoT2SAAY";
const citysearch = "https://dataservice.accuweather.com/locations/v1/";
const current = "https://dataservice.accuweather.com/currentconditions/v1/";


export { apikey, citysearch, current };
